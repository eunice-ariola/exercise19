package org.sunlife.training.codeA;

public class LotsOfErrors {
	public static void main(String[] args) {
		
		System.out.println("Hello World!");
		message();
	}
	
	
	public static void message() {
		
		System.out.print("This program surely cannot ");
		System.out.println("have any so called 'errors' in it");
	}
}
