package org.sunlife.training.CodeA;

public class LotsOfErrors {

	public static void main(String[] args) {
		
		System.out.println("Hello, world!");
		
		message();
	}
	
	
	public static void message() {
		
		System.out.println("This program surely cannot");
		System.out.println("any so-called \"errors\" in it");
	}
}
