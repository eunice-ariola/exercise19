package org.sunlife.training.CodeB;

public class GiveAdvice {

	public static void main(String[] args) {
		
		System.out.println("Programs can be easy or difficult");
		System.out.println("to read, depending upon their format.");
		System.out.println("Everyone, oincludeing yourself, will be");
		System.out.println("happier if you choose to format your");
		System.out.println("Programs");
	}
}
